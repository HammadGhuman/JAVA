package Task3;

public class HotWeapon {
    public void HotWeaponDescription() {
        System.out.println("Hot weapons uses gunpowder,");
    }
}
