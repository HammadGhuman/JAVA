package Task3;

public class NuclearWeapon extends Bomb {
    public void NuclearWeaponDescription() {
        System.out.println("Nuclear bombs blow up, and use nuclear fission and fusion.");
    }
}
