package Task3;

public class Weapon {
    public void Description() {
        System.out.println("Weapon description");
    }
}
