package Task3;

public class Bomb extends HotWeapon {
    public void BombDescription() {
        System.out.println("Bombs blow up");
    }
}
