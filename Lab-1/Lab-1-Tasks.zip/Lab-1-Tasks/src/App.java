import Task1.Student;
import Task2.MathTeacher;
import Task2.HumanitiesTeacher;
import Task2.ScienceTeacher;
import Task3.HotWeapon;
import Task3.Bomb;
import Task3.NuclearWeapon;
import Task4.Person;
import Task4.Artist;
import Task4.Gunman;

public class App {
    public static void main(String[] args) throws Exception {

        // uncomment the following line for task 1

        // Student student = Student.getStudentDetail();
        // student.displayStudentDetails();

        // uncomment the following line for task 2

        // var mathTeacher = MathTeacher.getHumanitiesTeacherData();
        // mathTeacher.displayTeacherDetails();
        // var humanitiesTeacher = HumanitiesTeacher.getHumanitiesTeacherData();
        // humanitiesTeacher.displayTeacherDetails();
        // var scienceTeacher = ScienceTeacher.getHumanitiesTeacherData();
        // scienceTeacher.displayTeacherDetails();

        // uncomment the following line for task 3

        // var hotWeapon = new HotWeapon();
        // hotWeapon.HotWeaponDescription();
        // var bomb = new Bomb();
        // bomb.BombDescription();
        // var nuclearWeapon = new NuclearWeapon();
        // nuclearWeapon.NuclearWeaponDescription();

        // uncomment the following line for task 4

        // var person = new Person("Hammad", "nan");
        // person.draw();
        // var artist = new Artist("Hammad");
        // artist.draw();
        // var gunman = new Gunman("Hammad");
        // gunman.draw();

    }
}