package Task4;

public class Person {
    private String name;
    private String occupation;

    public void draw() {
        System.out.println("a person can draw in many ways");
    }

    public Person(String name, String occupation) {
        this.name = name;
        this.occupation = occupation;
    }
}
